import React from 'react';
import Button from '@material-ui/core/Button';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Grow from '@material-ui/core/Grow';
import Popper from '@material-ui/core/Popper';
import { withStyles } from '@material-ui/core/styles';
import { View } from 'react-native';


  
const styles = theme => ({
  root: {
    display: 'flex',
    marginLeft: theme.spacing(7),
    marginTop: theme.spacing(3),

  },
  uploadbutton: {
    zIndex: theme.zIndex.drawer + 1,
  },
  paper: {
    marginRight: theme.spacing(2),
    background: 'hidden'
  },
  papermodal: {
    position: 'absolute',
    width: theme.spacing(50),
    backgroundColor: theme.palette.background.paper,
    boxShadow: theme.shadows[5],
    padding: theme.spacing(4),
    outline: 'none',
  },
 
  button: {
    backgroundColor: '#d8d8d8',
    width :'120px',
    height : '40px',
    fontWeight : 'bold',
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
  },
  dense: {
    marginTop: 16,
  },
});

class Any extends React.Component {
  state = {
    open: false,
    selectedIndex : 0,
    
  };

  handleListItemClick = (event, index) => {
    this.setState({ selectedIndex: index });
  };

  handleToggle = () => {
    this.setState(state => ({ open: !state.open }));
  };

  handleClose = event => {
    if (this.anchorEl.contains(event.target)) {
      return;
    }

    this.setState({ open: false });
  };
 

  render() {
    const { classes } = this.props;
    const { open } = this.state;

    return (
      <View className={classes.root}>
        
        <View className={classes.uploadbutton}>
          <Button
          className={classes.button}
            buttonRef={node => {
              this.anchorEl = node;
            }}
            aria-owns={open ? 'menu-list-grow' : undefined}
            aria-haspopup="true"
            onClick={this.handleToggle}
          >
            Upload
          </Button>
          <Popper open={open} anchorEl={this.anchorEl} transition disablePortal>
            {({ TransitionProps, placement }) => (
              <Grow
                {...TransitionProps}
                id="menu-list-grow"
                style={{ transformOrigin: placement === 'bottom' ? 'center top' : 'center bottom' }}
              >
                <Paper >
                <List component="nav" aria-label="main mailbox folders">
                        <ListItem button 
                        selected={this.state.selectedIndex === 1}
                        onClick={event => this.handleListItemClick(event, 1)}>
                        <ListItemIcon >
                        </ListItemIcon>
                        <ListItemText primary="Add folder" onClick={this.handlemodalOpen}/>
                        </ListItem>
                        <ListItem button
                        selected={this.state.selectedIndex === 2}
                        onClick={event => this.handleListItemClick(event, 2)}>
                        <ListItemIcon >
                        </ListItemIcon>
                            
                        </ListItem>
                        <ListItem button 
                        selected={this.state.selectedIndex === 3}
                        onClick={event => this.handleListItemClick(event, 3)}>
                        <ListItemIcon >
                        </ListItemIcon>
                                              
                        </ListItem>
                    </List>
                    
                </Paper>
              </Grow>
            )}
          </Popper>
        </View>
      </View>
    );
  }
}



export default withStyles(styles)(Any);
