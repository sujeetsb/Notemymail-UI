import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  KeyboardAvoidingView,
  TouchableOpacity,
  TouchableNativeFeedback
  
} from 'react-native';
import Menu, { MenuItem } from 'react-native-material-menu';
import { Icon } from 'react-native-elements'


  

export default class AddFile extends Component {

  
    state = {
      _Instimenu : '',
      _Profilemenu : '',
      _Productmenu : '',
    }

    
  
  setInstiMenuRef = ref => {
    this._Instimenu = ref;
  };

  hideInstiMenu = () => {
    this._Instimenu.hide();
  };

  showInstiMenu = () => {
    this._Instimenu.show();
  };

  setProfileMenuRef = ref => {
    this._Profilemenu = ref;
  };

  hideProfileMenu = () => {
    this._Profilemenu.hide();
  };

  showProfileMenu = () => {
    this._Profilemenu.show();
  };
  setProductMenuRef = ref => {
    this._Productmenu = ref;
  };

  hideProductMenu = () => {
    this._Productmenu.hide();
  };

  showProductMenu = () => {
    this._Productmenu.show();
  };
 

  render() {
   
    return (
        <KeyboardAvoidingView style={styles.container}>
            <View style={styles.textContainer}>
                <Text style={styles.text}>Case id :</Text>
                <TextInput style={styles.input} />

            </View>
            <TouchableNativeFeedback onPress={this.showInstiMenu}>
            <View style={styles.menu} >
                <Menu
                ref={this.setInstiMenuRef}
                button={<Text >Institute</Text>}
                >
                <MenuItem onPress={this.hideInstiMenu}>Kotak</MenuItem>
                <MenuItem onPress={this.hideInstiMenu}>Axis</MenuItem>
                <MenuItem onPress={this.hideInstiMenu}>DBS</MenuItem>
                <MenuItem onPress={this.hideInstiMenu}>HDFC</MenuItem>
                <MenuItem onPress={this.hideInstiMenu}>ICICI</MenuItem>

                </Menu>
                <Icon name="chevron-down"
                type="font-awesome"
                size={12}                
                />
            </View>
            </TouchableNativeFeedback>

            <TouchableNativeFeedback onPress={this.showProfileMenu}>
            <View style={styles.menu}>
                <Menu
                ref={this.setProfileMenuRef}
                button={<Text >Profile Type</Text>}
                >
                <MenuItem onPress={this.hideProfileMenu}>item</MenuItem>
                <MenuItem onPress={this.hideProfileMenu}>item 2</MenuItem>
                <MenuItem onPress={this.hideProfileMenu}>item 3</MenuItem>
                </Menu>
                <Icon name="chevron-down"
                type="font-awesome"
                size={12}     
                />
            </View>
            </TouchableNativeFeedback>

            <TouchableNativeFeedback onPress={this.showProductMenu}>
            <View style={styles.menu} >
                <Menu
                ref={this.setProductMenuRef}
                button={<Text >Product Type</Text>}
                >
                <MenuItem onPress={this.hideProductMenu}>item 1</MenuItem>
                <MenuItem onPress={this.hideProductMenu}>item 2</MenuItem>
                <MenuItem onPress={this.hideProductMenu}>item 3</MenuItem>
                </Menu>
                <Icon name="chevron-down"
                type="font-awesome"
                size={12}     
                />
            </View>
            </TouchableNativeFeedback>

            <TouchableOpacity style={[styles.buttonContainer, styles.loginButton]}  >
                <Text style={styles.loginText}>Get Documents</Text>
                <Icon name="camera" color="#ffffff" type="font-awesome" />
            </TouchableOpacity>
            

        </KeyboardAvoidingView>
      
      
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection:'column',
    justifyContent: 'space-evenly',
    alignItems: 'center',
  },
  textContainer:{
    flexDirection: 'row',
    justifyContent:'space-around'
  },
  input: {
      borderColor: '#dcdcdc',
      backgroundColor: '#FFFFFF',
      borderWidth: 1,
      width:150,
      height:45,
      paddingLeft:10,
      marginLeft:20,
      alignItems:'center'
  },
  text:{
      fontSize: 16
  },
  menu:{
    borderWidth: 1, 
    flexDirection:'row', 
    justifyContent:'space-between', 
    borderColor: '#dcdcdc', 
    padding:10, 
    width: 250,
    height:50, 
    alignItems: 'center' 

  },
  
  inputIcon:{
    width:30,
    height:30,
    marginLeft:20,
    justifyContent: 'center'
  },
  buttonContainer: {
    height:45,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginBottom:20,
    width:250,
    height:50,
    borderRadius:30,
  },
  loginButton: {
    backgroundColor: "#00b5ec",
  },
  loginText: {
    color: 'white',
    fontSize: 16
  },
  
});
 