import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  KeyboardAvoidingView,
  TouchableOpacity,
  
} from 'react-native';
import { Icon } from 'react-native-elements'

export default class Login extends Component {

  constructor(props) {
    super(props);
    state = {
      username   : '',
      password: '',
    }
  }

 

  render() {
    return (
      
      <KeyboardAvoidingView style={styles.container} behavior="padding" enabled>
        <View style={styles.inputContainer}>
          <Icon name='user'
            type='font-awesome' 
            color="#00aced"
            style={styles.inputIcon} />
          <TextInput style={styles.inputs}
              placeholder="Username"
              autoCompleteType="username"
              underlineColorAndroid='transparent'
              />
        </View>
        
        <View style={styles.inputContainer}>
        <Icon name='key'
            type='font-awesome' 
            color="#00aced"
            style={styles.inputIcon} />
        <TextInput style={styles.inputs}
              placeholder="Password"
              autoCompleteType="password"
              secureTextEntry={true}
              underlineColorAndroid='transparent'
              />
        </View>

        <TouchableOpacity style={[styles.buttonContainer, styles.loginButton]}  >
          <Text style={styles.loginText}>Login</Text>
        </TouchableOpacity>

        <View style={styles.textContainer}>
        <TouchableOpacity style={styles.buttonContainer} >
            <Text>Forgot your password?</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.buttonContainer} >
            <Text>Sign In</Text>
        </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputContainer: {
      borderColor: '#ededed',
      backgroundColor: '#FFFFFF',
      borderWidth: 1,
      width:250,
      height:45,
      paddingLeft:10,
      marginBottom:20,
      flexDirection: 'row',
      alignItems:'center'
  },
  inputs:{
      height:45,
      marginLeft:20,
      flex:1,
  },
  inputIcon:{
    width:30,
    height:30,
    marginLeft:20,
    justifyContent: 'center'
  },
  buttonContainer: {
    height:45,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom:20,
    width:250,
    borderRadius:30,
  },
  loginButton: {
    backgroundColor: "#00b5ec",
  },
  loginText: {
    color: 'white',
  },
  textContainer:{
    flexDirection: 'row',
    justifyContent:'space-around'
  }
});
 