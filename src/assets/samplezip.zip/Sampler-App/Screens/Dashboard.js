import React from 'react';
import {  View, StyleSheet, Text, TouchableOpacity, SafeAreaView } from 'react-native';



export default class Dashboard extends React.Component {
    render(){
  return (
    <SafeAreaView style={styles.container}>
       <TouchableOpacity style={[styles.buttonContainer, styles.Button]}  >
                <Text style={styles.buttonText}>Proccessed files</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.buttonContainer, styles.Button]}  >
                <Text style={styles.buttonText}>In-process files</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.buttonContainer, styles.Button]}  >
                <Text style={styles.buttonText}>Pending files</Text>
        </TouchableOpacity>


      <View style={styles.textcontainer}>
        <Text style={styles.text}>Sampled cases : </Text>
        <Text style={styles.text}>Verified documents : </Text>
        <Text style={styles.text}>Verified files : </Text>

    </View>
    </SafeAreaView>
    
  );
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-evenly',
    flexDirection:'column'
    
  },
  buttonContainer: {
    flex:1,
    justifyContent: 'space-around',
    alignItems: 'center',
    marginVertical:25,
    width:250,
  },
  Button: {
    backgroundColor: "#00b5ec",
  },
  buttonText: {
    color: 'white',
    fontSize: 20
  },

  textcontainer:{
      flex:2,
  },
  text:{
      fontSize: 20,
      margin:10
  }
});
